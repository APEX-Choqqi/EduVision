import customtkinter as ctk
import cv2
import numpy as np
import requests
from PIL import Image, ImageTk
from datetime import datetime
from tkinter import messagebox, filedialog

# --- SETUP ---
TOKEN = "shu yerga"
CHAT_ID = "shu yerga"

class EduVisionPro(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        self.title("EduVision AI Pro — Smart Management System")
        self.geometry("1200x850")
        ctk.set_appearance_mode("dark")
        
        # Ranglar palitrasi
        self.clr_sidebar = "#0F172A"
        self.clr_bg = "#1E293B"
        self.clr_accent = "#6366F1"  # Indigo
        self.clr_success = "#10B981" # Emerald
        self.clr_card = "#334155"
        
        self.user_role = None
        self.cap = None
        
        # Dastlab Login oynasini ko'rsatish
        self.show_login_screen()

    def clear_screen(self):
        for w in self.winfo_children(): w.destroy()
        if self.cap:
            self.cap.release()
            self.cap = None

    # --- 1. LOGIN OYNASI ---
    def show_login_screen(self):
        self.clear_screen()
        self.configure(fg_color=self.clr_bg)
        
        login_frame = ctk.CTkFrame(self, fg_color="transparent")
        login_frame.place(relx=0.5, rely=0.5, anchor="center")
        
        ctk.CTkLabel(login_frame, text="EduVision AI", font=("Poppins", 50, "bold"), text_color=self.clr_accent).pack(pady=10)
        ctk.CTkLabel(login_frame, text="Tizimga kirish turini tanlang", font=("Inter", 16), text_color="#94A3B8").pack(pady=(0, 40))
        
        btn_container = ctk.CTkFrame(login_frame, fg_color="transparent")
        btn_container.pack()
        
        # Teacher Login Card
        ctk.CTkButton(btn_container, text="👨‍🏫 O'QITUVCHI\n(Scanner & Admin)", width=300, height=180, 
                      corner_radius=25, fg_color=self.clr_card, border_width=2, border_color=self.clr_success,
                      font=("Inter", 18, "bold"), hover_color="#3D4D5D", 
                      command=lambda: self.enter_dashboard("teacher")).grid(row=0, column=0, padx=20)
        
        # Student Login Card
        ctk.CTkButton(btn_container, text="🎓 O'QUVCHI\n(AI Tutor & Results)", width=300, height=180, 
                      corner_radius=25, fg_color=self.clr_card, border_width=2, border_color=self.clr_accent,
                      font=("Inter", 18, "bold"), hover_color="#3D4D5D",
                      command=lambda: self.enter_dashboard("student")).grid(row=0, column=1, padx=20)

    def enter_dashboard(self, role):
        self.user_role = role
        self.show_main_dashboard()

    # --- 2. ASOSIY DASHBOARD ---
    def show_main_dashboard(self):
        self.clear_screen()
        
        # Sidebar (Navigatsiya)
        self.sidebar = ctk.CTkFrame(self, width=280, fg_color=self.clr_sidebar, corner_radius=0)
        self.sidebar.pack(side="left", fill="y")
        
        ctk.CTkLabel(self.sidebar, text="EduVision", font=("Poppins", 28, "bold"), text_color=self.clr_accent).pack(pady=40)
        
        # Menu elementlari
        if self.user_role == "teacher":
            self.add_menu_btn("📸 OMR Scanner", self.show_scanner_view)
            self.add_menu_btn("📝 Test Base", self.show_test_base)
            self.add_menu_btn("📊 Student Reports", self.show_reports)
        else:
            self.add_menu_btn("🤖 AI Personal Tutor", self.show_ai_tutor)
            self.add_menu_btn("📈 My Progress", self.show_student_stats)
            
        ctk.CTkButton(self.sidebar, text="Chiqish", fg_color="#EF4444", height=45, corner_radius=12,
                      command=self.show_login_screen).pack(side="bottom", pady=30, padx=20, fill="x")

        # Asosiy Content maydoni
        self.content = ctk.CTkFrame(self, fg_color=self.clr_bg, corner_radius=0)
        self.content.pack(side="right", fill="both", expand=True, padx=30, pady=30)
        
        # Boshlang'ich sahifa (Role'ga qarab)
        if self.user_role == "teacher": self.show_scanner_view()
        else: self.show_ai_tutor()

    def add_menu_btn(self, text, cmd):
        ctk.CTkButton(self.sidebar, text=text, fg_color="transparent", anchor="w", 
                      height=55, font=("Inter", 16), hover_color=self.clr_card, command=cmd).pack(pady=5, padx=15, fill="x")

    # --- 3. SAHIFALAR LOGIKASI ---

    def show_scanner_view(self):
        for w in self.content.winfo_children(): w.destroy()
        
        ctk.CTkLabel(self.content, text="Smart OMR Scanner", font=("Poppins", 32, "bold")).pack(anchor="w")
        ctk.CTkLabel(self.content, text="Varaqani skanerlash orqali natijani darhol ota-onaga yuboring", 
                     font=("Inter", 14), text_color="#94A3B8").pack(anchor="w", pady=(0, 20))
        
        # Camera & Stats Layout
        main_layout = ctk.CTkFrame(self.content, fg_color="transparent")
        main_layout.pack(fill="both", expand=True)
        
        # Kamera (Chapda)
        cam_container = ctk.CTkFrame(main_layout, fg_color="#000", corner_radius=25)
        cam_container.pack(side="left", fill="both", expand=True, padx=(0, 20))
        self.cam_label = ctk.CTkLabel(cam_container, text="Kamera tayyorlanmoqda...")
        self.cam_label.place(relx=0.5, rely=0.5, anchor="center")
        
        # Natija (O'ngda)
        stat_card = ctk.CTkFrame(main_layout, fg_color=self.clr_card, width=320, corner_radius=25)
        stat_card.pack(side="right", fill="y")
        stat_card.pack_propagate(False)
        
        ctk.CTkLabel(stat_card, text="NATIJA", font=("Inter", 18, "bold")).pack(pady=30)
        self.res_label = ctk.CTkLabel(stat_card, text="--", font=("Poppins", 60, "bold"), text_color=self.clr_success)
        self.res_label.pack()
        ctk.CTkLabel(stat_card, text="Ball: 0.0", font=("Inter", 16)).pack(pady=10)
        
        ctk.CTkButton(stat_card, text="⚡️ ANALIZ QILISH", fg_color=self.clr_success, height=50, 
                      corner_radius=15, font=("Inter", 16, "bold"), command=self.run_analysis).pack(pady=40, padx=20, fill="x")
        
        self.start_camera()

    def show_ai_tutor(self):
        for w in self.content.winfo_children(): w.destroy()
        
        ctk.CTkLabel(self.content, text="🤖 AI Personal Tutor", font=("Poppins", 32, "bold")).pack(anchor="w", pady=10)
        
        # AI Card
        ai_card = ctk.CTkFrame(self.content, fg_color=self.clr_accent, corner_radius=30)
        ai_card.pack(fill="x", pady=20)
        
        txt = "Xush kelibsiz, Avazbek! \nSiz oxirgi 'Kvant Fizikasi' testida 12-savolda xato qildingiz.\n" \
              "AI tahliliga ko'ra, sizga 'Eynshteyn fotoeffekti' mavzusini takrorlash tavsiya etiladi."
        
        ctk.CTkLabel(ai_card, text=txt, font=("Inter", 19), text_color="white", justify="left", wraplength=800).pack(pady=40, padx=40)
        ctk.CTkButton(ai_card, text="📚 Darsni Boshlash", fg_color="white", text_color=self.clr_accent, 
                      height=45, font=("Inter", 16, "bold")).pack(pady=(0, 40))

    # --- 4. FUNKSIONAL QISM ---
    def start_camera(self):
        self.cap = cv2.VideoCapture(0)
        self.update_camera_frame()

    def update_camera_frame(self):
        if self.cap:
            ret, frame = self.cap.read()
            if ret:
                # DTM Varaqa Focus Ramkasi
                h, w, _ = frame.shape
                cv2.rectangle(frame, (w//4, h//8), (3*w//4, 7*h//8), (99, 102, 241), 3)
                
                img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(img)
                img_tk = ImageTk.PhotoImage(image=img)
                self.cam_label.configure(image=img_tk, text="")
                self.cam_label.image = img_tk
                self.after(10, self.update_camera_frame)

    def run_analysis(self):
        # AI Analiz Simulyatsiyasi
        correct = np.random.randint(18, 30)
        ball = round(correct * 3.1, 1)
        self.res_label.configure(text=f"{correct}/30")
        
        # Telegram xabarnoma
        msg = f"🚀 *EduVision Pro: Yangi Natija*\n\n✅ To'g'ri: {correct}/30\n📊 Ball: {ball}\n👤 O'quvchi: Avazbek\n🤖 AI: Xatolar bo'yicha individual dars yuklandi."
        try:
            requests.post(f"https://api.telegram.org/bot{TOKEN}/sendMessage", data={"chat_id": CHAT_ID, "text": msg, "parse_mode": "Markdown"})
            messagebox.showinfo("Muvaffaqiyat", "Natija tahlil qilindi va ota-onaga yuborildi!")
        except: pass

    # Bo'sh sahifalar simulyatsiyasi
    def show_test_base(self): messagebox.showinfo("Baza", "Testlar bazasi yuklanmoqda...")
    def show_reports(self): messagebox.showinfo("Hisobot", "Barcha talabalar natijalari jadvali...")
    def show_student_stats(self): messagebox.showinfo("Statistika", "Sizning o'sish ko'rsatkichlaringiz...")

if __name__ == "__main__":
    app = EduVisionPro()
    app.mainloop()